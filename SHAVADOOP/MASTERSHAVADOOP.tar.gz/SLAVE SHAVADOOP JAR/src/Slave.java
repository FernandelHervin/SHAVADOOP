import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
//import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

public class Slave {

	//========================================================Simulation d'un calcul pendant 10s(Sleep 10s)=======================================================================
	
	public static void attente10s() throws InterruptedException{
		int i = 0;
		for(i=0;i<10;i++)
		{
			Thread.sleep(1000);
		}
		System.out.println("10s");
	}
	
	//============================================================Question 26: Création des fichiers UMx========================================================================

	public static void question26(String [] s) throws IOException{
		HashMap<String, String> hm = new HashMap<>();
		String mode = "SxUMx";
		String Pathin = s[s.length -1];
		if(mode.equals(s[0])){
			//String Pathin = s[2];
			FileReader file = null;
			String line;
			file = new FileReader(Pathin+s[1]+".txt"); // permet la lecture des fichiers Sx
			BufferedReader buff = new BufferedReader(file);
			String fic = s[1];
			char[] chars = fic.toCharArray();
			String count = null;
			count = fic.substring(2,chars.length); // permet de récupérer le numéro du fichier Sx et de le passer à une variable count qui va ajouter le numéro du duchier UMx
			
			while ((line = buff.readLine()) != null)
			{
				String[] words = line.split(" ");

				//BufferedWriter writer = new BufferedWriter(new FileWriter(new File("/cal/homes/kakpo/workspace/UMx"+count+".txt")));  // Création des fichires UMx
				BufferedWriter writer = new BufferedWriter(new FileWriter(new File(Pathin+"UMx"+count+".txt")));  // Création des fichires UMx
				for (int i=0; i<words.length; i++){
					writer.write(String.valueOf(words[i]+ " " + 1 + "\r\n"));
				}

				writer.close();
				//BufferedWriter writer1 = new BufferedWriter(new FileWriter(new File("/cal/homes/kakpo/workspace/UM"+count+".txt"))); // Création des fichiers UM
				BufferedWriter writer1 = new BufferedWriter(new FileWriter(new File(Pathin+"UM"+count+".txt"))); // Création des fichiers UM
				for (int i=0; i<words.length; i++){
					hm.put(words[i], "1");
					writer1.write(String.valueOf(words[i]+"\r\n"));
				}
				writer1.close();

			}
		}

	}
	//============================================================Question 28: Création des fichiers UMx========================================================================

	/*	public static void question28(String s) throws IOException{
		HashMap<String, String> hm = new HashMap<>();

		 HashMap ht = new HashMap <String, List <String>>();

		BufferedReader lecteurAvecBuffer = null;
		//String ligne;
		//String fichier = "doc.txt";
		//String file = "fichiersorti.txt";
		FileReader file = null;
		String line;
		file = new FileReader("/cal/homes/kakpo/workspace/"+s+".txt");
		BufferedReader buff = new BufferedReader(file);
		String fic = s;
		char[] chars = fic.toCharArray();
		String [][] tab = null;	
		//System.out.println (chars[2]);

		while ((line = buff.readLine()) != null)
		{
			String[] words = line.split(" ");
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File("/cal/homes/kakpo/workspace/UM"+chars[2]+".txt")));
			for (int i=0; i<words.length; i++){
				hm.put(words[i], "1");
				writer.write(String.valueOf(words[i]+"\r\n"));
			}
			System.out.println(hm.keySet());
			writer.close();					
				}buff.close();			
			}
	 */
	//===========================================================Question 29 jusqu'à 33: Création des fichiers SMx RMx========================================================================

	public static void question31_32(String [] b) throws IOException{

		String mode = "UMxSMx";
		if(b[0].equals(mode)){
			FileReader file = null;
			String line;
			String fic = b[2];
			char[] chars = fic.toCharArray();
			String countSM = (String)b[b.length-1];
			String Pathin = b[b.length-2];
			ArrayList<String> temp = new ArrayList<String>();
			ArrayList<String> tampo = new ArrayList<String>();

			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(Pathin+"SMx"+countSM+".txt")));

			for(int i = 3; i<b.length-2;i++){	

				file = new FileReader(Pathin +b[i]+".txt");

				BufferedReader buff = new BufferedReader(file);	
				while ((line = buff.readLine()) != null){
					for (String words : line.split(" ")){
						if (words.equals(b[1])){
							tampo.add(words);					
							writer.write(String.valueOf(words+ " " +"1"+ "\r\n"));

						}

					}

				}	

			}writer.close();

			BufferedWriter writer1 = new BufferedWriter(new FileWriter(new File(Pathin+"RMx"+countSM+".txt")));
			writer1.write(String.valueOf(b[1]+ " " +tampo.size()+ "\r\n"));
			System.out.println(b[1]+ " " +tampo.size());
			writer1.close();
		}

	}



	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		question26(args);
		question31_32(args);






	}

}
