import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MASTER {

	//========================================Connexion aux machines et renvoie les machines connectées question18===================================================================

	public static ArrayList<String> connexion(String []args) throws IOException, InterruptedException{
		System.out.println("==========================================Vérification des machines connectées======================================================="+"\n");
		
		String ligne;
		
		String Pathin=args[0];
		String listmachine = args[1];
		BufferedReader lecteurAvecBuffer = null;
		ArrayList<String> machines = new ArrayList<String>();
		ArrayList<String> nouvel_machines = new ArrayList<String>();
		try
		{
			lecteurAvecBuffer = new BufferedReader(new FileReader(Pathin+listmachine));
		}
		catch(FileNotFoundException exc)
		{
			System.out.println("Erreur d'ouverture");
		}
		while ((ligne = lecteurAvecBuffer.readLine()) != null){ // lecture des lignes du fichier

			machines.add(ligne);
		}	

		lecteurAvecBuffer.close();

		BufferedWriter writer = new BufferedWriter(new FileWriter(new File(Pathin+"listemachineOK.txt")));  //renvoie les machines connectées

		for (String myMachine : machines){
			String cmd_1 [] = {"ssh", myMachine, "pwd"};
			ProcessBuilder print = new ProcessBuilder(cmd_1);// création du process builder au niveau système
			Process process = print.start();
			process.waitFor();
			if (process.exitValue()==0){
				//System.out.println("ok:" + myMachine);
				nouvel_machines.add(myMachine);
				writer.write(String.valueOf(myMachine)+ "\r\n");
			}
		}
		writer.close();
		System.out.println("Nombres de machines connectées: "+nouvel_machines.size());
		return nouvel_machines;

	}

	//==============================================Question 25: création des fichiers Sx============================================================================

	public static ArrayList<String> question25(String []args) throws IOException{
		long startTime = System.currentTimeMillis();
		String Pathin=args[0];
		String line;
		String Filename = args[2];
		int k = 0;
		ArrayList<String> nbrefichier = new ArrayList<String>();
		FileReader fr = new FileReader(Pathin+Filename); //Fichier d'entrée contenant tous les mots
		BufferedReader br = new BufferedReader(fr); 
		FileWriter fw = new FileWriter("outfile.txt"); 
		String lines;
		System.out.println("======================================Question25: contenu du fichier d'entrée nettoyé================================================"+"\n");
		while((lines = br.readLine()) != null)
		{ 
			lines = lines.trim(); // remove leading and trailing whitespace

			if (!lines.equals("")) // don't write out blank lines
			{
				fw.write(String.valueOf(lines.toLowerCase()).replaceAll("[^\\p{L}\\p{M}\\p{P}\\p{Nd}\\s]+", "").replaceAll("'", " ").replaceAll(":", "").replaceAll("(?m)^[ \t]*\r?\n", "nettoyer").replace(".", "carace")+ "\r\n");
			}

			

		} 
		fr.close();
		fw.close();
		System.out.println("====================================================================================================================================="+"\n");
		FileReader file = null;
		file = new FileReader("outfile.txt"); 
		BufferedReader buff = new BufferedReader(file);

		while ((line = buff.readLine()) != null)
		{
			
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(Pathin+"Sx"+k+".txt")));
			writer.write(String.valueOf(line)+ "\r\n");
			nbrefichier.add("Sx"+k);
			k = k+1;
			writer.close();	
		}buff.close();
		long endTime   = System.currentTimeMillis();
		long totalTime = endTime - startTime;
		System.out.println("==========================================Durée d'exécution du splitting du fichier Sx=============================================="+"\n");
		System.out.println("Splitting Sx files duration: " +totalTime+"ms"+"\n");
		System.out.println("====================================================================================================================================="+"\n");	
		return nbrefichier;

	}

	//============================================================Création des fichiers UMx==========================================================================

	public static ArrayList<String> question27(ArrayList<String> machineconnecte, ArrayList<String> nbrefichier, String Path) throws IOException, InterruptedException{
		long startTime = System.currentTimeMillis(); //============= Initialisation du compteur de temps
		String mode = "SxUMx";
		String Pathin = Path;
		ArrayList<String> nbrefichierUM = new ArrayList<String>();
		Runner_slave[] runner_slave = new Runner_slave[nbrefichier.size()];
		//System.out.println(nbrefichier.size());

		//for (int i = 0; i< runner_slave.length; i++){
		for (int i = 0; i< nbrefichier.size(); i++){
			//System.out.println("Avant calcul:"+machineconnecte.get(i));
			runner_slave[i] = new Runner_slave(machineconnecte.get(i), nbrefichier.get(i), mode, Pathin);
			//System.out.println("Avant calcul:"+machineconnecte.get(i) +"  "+nbrefichier.get(i));
			runner_slave[i].start();

		}
		//for (int i = 0; i< runner_slave.length; i++){
		for (int i = 0; i< nbrefichier.size(); i++){
			runner_slave[i].join();
			//System.out.println("Apres calcul: UM"+i+" "+ "UMx"+i);
			nbrefichierUM.add("UMx"+i);
			//	System.out.println("nbrefichierUM "+nbrefichierUM);
		}
		//System.out.println("Calcul UMx tout est fini");
		long endTime   = System.currentTimeMillis();
		long totalTime = endTime - startTime;
		System.out.println("Splitting UMx files duration " +totalTime+"ms"+"\n");

		return nbrefichierUM;		
	}

	// creation de la partie trois de l'algorithme
	//===========================================================Question 28 et 29: Création des fichiers UM========================================================================	
	public static ArrayList<String> question29(ArrayList<String> machineconnecte, ArrayList<String> nbrefichierUM, String []args) throws InterruptedException, IOException{

		String mode = "SxUMx";
		String Pathin=args[0];
		HashMap Dictionnaire = new HashMap <String, List <String>>();
		ArrayList<String> valUM = new ArrayList<String>();

		ArrayList<String> result = new ArrayList<String>();

		HashMap<String, String> hm = new HashMap<String, String>();
		HashMap<String, HashSet<String>> ht = new HashMap<String, HashSet<String>>();
		String lines;
		if(mode.equals("SxUMx")){
			long startTime = System.currentTimeMillis();
			FileReader file = null;

			Runner_slave[] runner_slave = new Runner_slave[nbrefichierUM.size()];
			for (int i = 0; i< nbrefichierUM.size(); i++){
				//System.out.println("Création UMx:"+nbrefichierUM.get(i));
				//System.out.println("machineconnecte.get(i): "+machineconnecte.get(i)+ " nbrefichierUM.get(i): "+nbrefichierUM.get(i));
				valUM.add("UM"+i);
				runner_slave[i] = new Runner_slave(machineconnecte.get(i), nbrefichierUM.get(i), mode, Pathin);
				runner_slave[i].start();
				runner_slave[i].join();

			}
			//System.out.println("Test connexion2");
			System.out.println("================================================Affichage des clés, machines======================================================"+"\n");
			for (int i = 0; i< nbrefichierUM.size(); i++){
				System.out.println("clés-machines: < UMx"+i+" "+ machineconnecte.get(i)+" >");
			}
			System.out.println("===================================================================================================================================="+"\n");

			for (int i = 0; i < valUM.size();i++){
				file = new FileReader(Pathin+"UM"+i+".txt");
				HashSet<String> unique_word = new HashSet<String>();
				BufferedReader buff = new BufferedReader(file);

				while ((lines = buff.readLine()) != null)
				{
					for (String word : lines.split(" ")) {
						unique_word.add(word);
					}
				}
				for (int ii=0 ; ii< unique_word.size(); ii++){
					String s = unique_word.toArray()[ii].toString(); 
					ArrayList<String> temp = new ArrayList<String>();
					temp.add("UM"+i);

					if (Dictionnaire.containsKey(s)){
						ArrayList<String> list = new ArrayList<String>();
						list = (ArrayList<String>)Dictionnaire.get(s);
						list.add("UM"+i);
						Dictionnaire.put(s,list);
					}
					else {
						Dictionnaire.put(s, temp); 
					}


				}  

			}file.close();
			System.out.println("=====================================Affichage des clés et des fichies contenant les clés==============================================="+"\n");
			System.out.println(Dictionnaire+"\n");
			System.out.println("========================================================================================================================================"+"\n");
			result.addAll(Dictionnaire.keySet());

			mode ="UMxSMx";
			long endTime   = System.currentTimeMillis();
			long totalTime = endTime - startTime;
			System.out.println("====================================Durée d'exécution du Mapping du fichier Sx en UMx============================================="+"\n");
			System.out.println("Splitting UMx files duration Sx => UMx" +totalTime+"ms");
			System.out.println("=================================================================================================================================="+"\n");	
		}
		//===========================================================Question 33,34,35: Création des fichiers SMx RMx========================================================================

		long startTime = System.currentTimeMillis();

		if (mode.equals("UMxSMx")){
			ArrayList<String> mot = new ArrayList<String>();
			ArrayList<String> finalresult = new ArrayList<String>();
			String RM; 

			Runner_slave[] runner_slave = new Runner_slave[result.size()];			
			for (int l = 0; l < nbrefichierUM.size();l++){
				mot.add("UM"+l);	
			}
			String mots = mot.toString();

			String motfinal = mots.replace(",","").replace("[","").replace("]","");


			for (int i = 0; i< result.size(); i++){ //Démarrage des slaves on récupére les clés et valeurs de sorties du RMx dans un arraylist grâce à getInputStream
				RM = "RM"+i;
				runner_slave[i] = new Runner_slave(machineconnecte.get(i),mode, result.get(i), RM, motfinal, i,Pathin);
				runner_slave[i].start();
				runner_slave[i].join();
				finalresult.add(runner_slave[i].resultafinal.get(0));			
			}

			long endTime   = System.currentTimeMillis();
			long totalTime = endTime - startTime;
			System.out.println("==================================Durée d'exécution du Shffling et Reducing SMx et RMx============================================"+"\n");
			System.out.println("Splitting UMx => SMx + SMx=> RMx files duration:  " +totalTime+" ms");
			System.out.println("=================================================================================================================================="+"\n");	

			//======================================================Question 36: Final Result Dictionnary===============================================================================================			

			long startTime1 = System.currentTimeMillis();

			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(Pathin+"FinalResult.txt")));
			for (String elt: finalresult){
				writer.write(String.valueOf(elt+"\r\n"));
			}writer.close();

			long endTime1   = System.currentTimeMillis();
			long totalTime1 = endTime1 - startTime1;
			System.out.println("==========================================Durée d'exécution résultat final========================================================"+"\n");
			System.out.println("Assembling file duration " +totalTime1);
			System.out.println("=================================================================================================================================="+"\n");
		}
		return valUM ;
	}

	public static void question30(ArrayList<String>a){

		System.out.println("Tout est fini");

	}

	public static void main(String[] args) throws IOException, InterruptedException{
		// TODO Auto-generated method stub
		question30(question29(connexion(args),question25(args),args));

		//question 18
		/*ArrayList<String> machines = new ArrayList<String>();
		ArrayList<String> nouvel_machines = new ArrayList<String>();

		try
		{
			lecteurAvecBuffer = new BufferedReader(new FileReader(fichier));
		}
		catch(FileNotFoundException exc)
		{
			System.out.println("Erreur d'ouverture");
		}
		while ((ligne = lecteurAvecBuffer.readLine()) != null){
			System.out.println(ligne);write
			machines.add(ligne);
		}	


		lecteurAvecBuffer.close();

		//File f  = new File("fichiersorti.txt");
		BufferedWriter writer = new BufferedWriter(new FileWriter(new File("fichiersorti.txt")));

		for (String myMachine : machines){
			String cmd_1 [] = {"ssh", myMachine, "pwd"};
			ProcessBuilder print = new ProcessBuilder(cmd_1);// création du process builder au niveau système
			Process process = print.start();
			process.waitFor();
			if (process.exitValue()==0){
				System.out.println("ok:" + myMachine);
				nouvel_machines.add(myMachine);
				writer.write(String.valueOf(myMachine)+ "\r\n");
			}

		}
		 writer.close();
	
	//Question 20

		 int i = 0;write
		 String cmd_3 [] = {"ssh", nouvel_machines.get(i),"java -jar /cal/homes/kakpo/Desktop/Slave.jar"};
		 ProcessBuilder print = new ProcessBuilder(cmd_3);
		 Process [] pbs = new Process[nouvel_machines.size()];
		 for (int u=0;u<pbs.length;u++){
			 pbs[u] = print.start();
			 pbs[u].waitFor();

		 }

			 // création du process builder au niveau système
			 Process process = print.start();
			 process.waitFor();
			 InputStream value = process.getInputStream(); // récupère le resultat du calcul au niveau système
		     InputStreamReader value_read = new InputStreamReader(value);  // crée un un readear 
		     BufferedReader bufferedReader = new BufferedReader(value_read); // envoie le reader dans le duffer

		        //BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
		     process.waitFor();
		     String line;
		    while((line = bufferedReader.readLine()) != null){
		        System.out.println(line);

		    }*/
		/*	// Question 22

		ArrayList<String> goodMachine = new ArrayList<String>();

		file = new FileReader("fichiersorti.txt");
		BufferedReader buff = new BufferedReader(file);
		while ((line = buff.readLine()) != null)
		{
			System.out.println("On lance Slave:"+line);
			goodMachine.add(line);
		}

		Runner_slave[] runner_slave = new Runner_slave[goodMachine.size()];
		for (int i = 0; i< runner_slave.length; i++){
			System.out.println("Avant calcul:"+goodMachine.get(i));
			runner_slave[i] = new Runner_slave(goodMachine.get(i));
			runner_slave[i].start();

		}
		for (int i = 0; i< runner_slave.length; i++){
			runner_slave[i].join();
			System.out.println("Apres calcul:"+goodMachine.get(i));
		}
		System.out.println("tout est fini");


	//Question 21 
		    //System.out.println("Tout est fini");*/

		//Question 25 

		/*	Map<String, Integer> hm = new HashMap<>();
		ArrayList<String> Input = new ArrayList<String>();
		//String [] Input = null;
		file = new FileReader("Input.txt");
		BufferedReader buff = new BufferedReader(file);
		int k = 0;
		while ((line = buff.readLine()) != null)
		{
			System.out.println(line);
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File("/cal/homes/kakpo/workspace/Sx"+k+".txt")));
			writer.write(String.valueOf(line)+ "\r\n");
			k = k+1;
			//Input.add(line);+
			writer.close();	
		}*/

		/*	for(String mot : Input){
			int k = 0;
			//System.out.println(mot);
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File("Sx"+k+".txt")));

			writer.write(String.valueOf(mot)+ "\r\n");

			/*for(String mots : mot.split(" ")){
				//System.out.println(mots);
				hm.put(mots, 1);

			}

			writer.close();	
			k = k+1;
		} */

		//System.out.println(hm);



	}


}





