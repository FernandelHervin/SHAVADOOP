import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

class Runner_slave extends Thread {

	private String ip;
	private String Fic;
	private String mode;
	private String cle;
	public String rm;
	private String UM;
	private int count;
	private String Path;
	public ArrayList<String> resultafinal = new ArrayList<String>()  ;





	public String getIp() {
		return ip;
	}
	public int getcount() {
		return count;
	}
	public String getFic(){
		return Fic;  	
	}
	public String geMode(){
		return mode;  	
	}
	public String getCle(){
		return cle;  	
	}
	public String getrm(){
		return rm;  	
	}
	public String getUM(){
		return UM;  	
	}
	public String getPath(){
		return Path;  	
	}
	public ArrayList<String> getresultafinal(){
		return resultafinal;  	
	}

	public void setIp(String ip) {
		this.ip = ip;
	}
	public void setcount(int count) {
		this.count = count;
	}


	public void setFic(String Fic){
		this.Fic = Fic;
	}
	
	public void setMode(String mode){
		this.mode = mode;
	}
	
	public void setCle(String cle){
		this.cle = cle;
	}
	
	public void setnomfin(String rm){
		this.rm = rm;
	}
	
	public void setUM(String UM){
		this.UM = UM;
	}
	public void setPath(String Path){
		this.Path = Path;
	}

	public Runner_slave(String ip, String Fic) {
		super();
		this.ip = ip;
		this.Fic = Fic;
	}

	public Runner_slave(String ip, String Fic, String mode, String Path) {
		super();
		this.ip = ip;
		this.Fic = Fic;
		this.mode = mode;
		this.Path=Path;
	}
	public Runner_slave(String ip, String mode, String cle, String rm ,String UM, int count,String Path) {
		super();
		this.ip = ip;
		this.mode = mode;
		this.cle = cle;
		this.rm=rm;
		this.UM = UM;
		this.count = count;
		this.Path=Path;

	}

	@Override
	public void run() {
		if(mode.equals("SxUMx")){
			String[] cmd_2 = {"ssh","-o StrictHostKeyChecking=no", ip , "java -jar "+Path+"SlaveSHAVADOOP.jar"+" "+ mode +" "+Fic +" "+Path};
			ProcessBuilder pb2 = new ProcessBuilder(cmd_2);
			Process p2;
			try {
				p2 = pb2.start();
				AfficheurFlux fluxSortie = new AfficheurFlux(p2.getInputStream());
				AfficheurFlux fluxErreur = new AfficheurFlux(p2.getErrorStream());

				Thread Sortie = new Thread(fluxSortie);
				Thread Erreur = new Thread(fluxErreur);

				Erreur.start();
				Sortie.start();

				Erreur.join();
				Sortie.join();

				p2.waitFor();


			} catch (IOException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		if(mode.equals("UMxSMx")){
			String[] cmd_2 = {"ssh","-o StrictHostKeyChecking=no", ip, "java -jar "+Path+"SlaveSHAVADOOP.jar"+" "+mode+" "+cle+" "+rm+" "+UM+" "+Path+" "+count};
			ProcessBuilder pb2 = new ProcessBuilder(cmd_2);
			Process p2;
			try {
				p2 = pb2.start();
				AfficheurFlux fluxSortie = new AfficheurFlux(p2.getInputStream());
				AfficheurFlux fluxErreur = new AfficheurFlux(p2.getErrorStream());

				Thread Sortie = new Thread(fluxSortie);
				Thread Erreur = new Thread(fluxErreur);

				Erreur.start();
				Sortie.start();

				Erreur.join();
				Sortie.join();

				p2.waitFor();


				//Recuperation des flux de sorties

				if(p2.exitValue() ==0)
				{
					fluxSortie.run();
					for( int k = 0; k< fluxSortie.tab.size(); k++)
					{
						resultafinal.add(fluxSortie.tab.get(k));
					}

				}

			} catch (IOException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

}
